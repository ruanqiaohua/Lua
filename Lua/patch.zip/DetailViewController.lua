waxClass{"DetailViewController", UIViewController}

function viewDidLoad (self)
self:view():setBackgroundColor(UIColor:yellowColor())
end