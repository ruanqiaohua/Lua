waxClass{"FirstDetailViewController", UIViewController}

function viewDidLoad (self)
self:view():setBackgroundColor(UIColor:whiteColor())
end