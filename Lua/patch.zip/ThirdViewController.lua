waxClass{"ThirdViewController", UIViewController}

function viewDidLoad (self)
self:view():setBackgroundColor(UIColor:greenColor())
end