waxClass{"ViewController", UIViewController}

function viewDidLoad(self)

self:view():setBackgroundColor(UIColor:purpleColor())

end